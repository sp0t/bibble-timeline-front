export const storyForm = state => state.storyForm;
