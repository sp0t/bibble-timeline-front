export const eventForm = state => state.eventForm;
