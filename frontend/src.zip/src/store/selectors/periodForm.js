export const periodForm = state => state.periodForm;
