export const characterForm = state => state.characterForm;
