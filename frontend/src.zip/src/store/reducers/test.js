const test = () => ({ something: 'test' });

export default test;
