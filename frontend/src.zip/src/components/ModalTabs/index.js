export { default } from './ModalTabs';
