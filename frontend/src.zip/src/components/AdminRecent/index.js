export { default } from './AdminRecent';
