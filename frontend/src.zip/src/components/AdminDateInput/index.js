export { default } from './AdminDateInput';
