export { default } from './AdminRelationContainer';
