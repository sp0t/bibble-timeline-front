export { default } from './DimensionalPeriod';
