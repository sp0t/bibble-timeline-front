export { default } from './AdminTable';
