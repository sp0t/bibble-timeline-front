export { default } from './AdminDeleteModal';
