export { default } from './AdminCharacterRelationBlock';
