export { default } from './MediaImage';
