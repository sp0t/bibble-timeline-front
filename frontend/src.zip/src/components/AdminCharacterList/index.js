export { default } from './AdminCharacterList';
