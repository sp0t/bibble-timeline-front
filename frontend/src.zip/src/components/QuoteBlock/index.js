export { default } from './QuoteBlock';
