export { default } from './AdminPageTitle';
