export { default } from './AdminCharacterRelation';
