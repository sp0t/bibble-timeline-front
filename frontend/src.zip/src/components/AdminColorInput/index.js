export { default } from './AdminColorInput';
