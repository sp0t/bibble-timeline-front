export { default } from './CharacterDot';
