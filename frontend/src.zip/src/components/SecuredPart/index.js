export { default } from './SecuredPart';
