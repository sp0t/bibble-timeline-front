export { default } from './CharacterBlock';
