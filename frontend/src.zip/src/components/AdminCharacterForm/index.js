export { default } from './AdminCharacterForm';
