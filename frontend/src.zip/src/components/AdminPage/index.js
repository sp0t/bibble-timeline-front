export { default } from './AdminPage';
